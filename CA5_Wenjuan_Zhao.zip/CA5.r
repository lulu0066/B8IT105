
# Assignment: CA5 
# Student ID : 10543531
# Student Name: Wenjuan Zhao
# Git hub: https://github.com/lulu0066/B8IT105.git 

library(ggplot2)
library(tibble)
getwd()
setwd('/Users/xxxxxx/B8IT105')

# Import titanic csv file
titanic <- read.csv("Titanic.csv", stringsAsFactors = FALSE)

# view structure of titanic csv file
view(titanic)
str(titanic)
summary(titanic)

# set up factors
titanic$Survived <- as.factor(titanic$Survived)
titanic$Pclass <- as.factor(titanic$Pclass)
titanic$Sex <- as.factor(titanic$Sex)
titanic$Embarked <- as.factor(titanic$Embarked)

# percetage
prop.table(table(titanic$Survived))

# Titanic passenger survival rate, more than half of passengers have died.
ggplot(titanic, aes(x = Survived)) + 
  theme_gray() + 
  geom_bar() + 
  labs(y = ' Passenger Count', title = 'Survival Rate')

# Titanic passenger survival rate by sex, most male have died, most femal have survied
ggplot(titanic, aes(x = Sex, fill= Survived)) + 
  theme_gray() + 
  geom_bar() + 
  labs(y = ' Passenger Count', title = 'Survival Rate by Sex')

# Titanic passenger survival rate by class, more than half of the passengers have survide 
# in the 1st class, about half of passengers have survided in the 2nd class, most of 
# passengers have died in the 3rd class.
ggplot(titanic, aes(x = Pclass, fill= Survived)) + 
  theme_gray() + 
  geom_bar() + 
  labs(y = ' Passenger Count', title = 'Survival Rate by Class')

# Titanic passenger survival rate by class and sex, most femal and less than half of male 
# have suvived in the 1st class, most femal and less than a quarter of mail have survived,
# half of femail and small amount of male have survived in the 3rd class
ggplot(titanic, aes(x = Sex, fill= Survived)) + 
  theme_gray() + 
  facet_wrap(~ Pclass) +
  geom_bar() + 
  labs(y = ' Passenger Count', title = 'Survival Rate by Class and Sex')

# The distribution of the passenger's age, the plot shows that most passengers are between 20s to 40s
ggplot(titanic, aes(x = Age)) + 
  theme_gray() + 
  geom_histogram(binwidth = 5) +   # 5 as a block, 5 years of age diffenece
  labs(y = ' Passenger Count', 
       x = 'Age(binwidth = 5)',
       title = 'Age Distribution')

# Titanic passenger survival rate by age using histogram, it seems most children have survived,
# age group ween 20 - 40 survived less than 50%, most elderly have died.
ggplot(titanic, aes(x = Age, fill=Survived)) + 
  theme_gray() + 
  geom_histogram(binwidth = 5) +   
  labs(y = ' Passenger Count', 
       x = 'Age(binwidth = 5)',
       title = 'Survival Rate by Age')
    
# Titanic passenger survival rate by age using box plot, it seems that the passengers who
# survided are younger
ggplot(titanic, aes(x = Survived, y = Age)) + 
  theme_gray() + 
  geom_boxplot() +   
  labs(y = ' Age', 
       x = 'Survived',
       title = 'Survival Rate by Age')

# Titanic passenger survival rate by age,class and sex using histrogram. It shows that in 1st 
# and 2nd class, most femal have survived, all girls have survided in 2nd class, half femal 
# have survived in 3rd class; most boys in 1st and 2nd class have survived, most older male 
# have died
ggplot(titanic, aes(x = Age, fill= Survived)) + 
  theme_gray() + 
  facet_wrap(Sex ~ Pclass) +
  geom_histogram(binwidth = 5) + 
  labs(y = 'Survived',
       x = 'Age',
       title = 'Survival Rate by Age, Class and Sex')