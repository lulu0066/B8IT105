
# Assignment: CA3 
# Student ID : 10543531
# Student Name: Wenjuan Zhao
# Git hub: https://github.com/lulu0066/B8IT105.git 

library(ggplot2)
library(tibble)
getwd()
setwd('/Users/markmullan/B8IT105')

# Import titanic csv file
titanic <- read.csv("Titanic.csv", stringsAsFactors = FALSE)

# view structure of titanic csv file
view(titanic)
str(titanic)
summary(titanic)

# set up factors
titanic$Survived <- as.factor(titanic$Survived)
titanic$Pclass <- as.factor(titanic$Pclass)
titanic$Sex <- as.factor(titanic$Sex)
titanic$Embarked <- as.factor(titanic$Embarked)

# percetage
prop.table(table(titanic$Survived))

# Titanic passenger survival rate
ggplot(titanic, aes(x = Survived)) + 
  theme_gray() + 
  geom_bar() + 
  labs(y = ' Passenger Count', title = 'Survival Rate')

# Titanic passenger survival rate by sex
ggplot(titanic, aes(x = Sex, fill= Survived)) + 
  theme_gray() + 
  geom_bar() + 
  labs(y = ' Passenger Count', title = 'Survival Rate by Sex')

# Titanic passenger survival rate by class
ggplot(titanic, aes(x = Pclass, fill= Survived)) + 
  theme_gray() + 
  geom_bar() + 
  labs(y = ' Passenger Count', title = 'Survival Rate by Class')

# Titanic passenger survival rate by class and sex
ggplot(titanic, aes(x = Sex, fill= Survived)) + 
  theme_gray() + 
  facet_wrap(~ Pclass) +
  geom_bar() + 
  labs(y = ' Passenger Count', title = 'Survival Rate by Class and Sex')

# The distribution of the passenger's age
ggplot(titanic, aes(x = Age)) + 
  theme_gray() + 
  geom_histogram(binwidth = 5) +   # 5 as a block, 5 years of age diffenece
  labs(y = ' Passenger Count', 
       x = 'Age(binwidth = 5)',
       title = 'Age Distribution')

# Titanic passenger survival rate by age using histogram
ggplot(titanic, aes(x = Age, fill=Survived)) + 
  theme_gray() + 
  geom_histogram(binwidth = 5) +   
  labs(y = ' Passenger Count', 
       x = 'Age(binwidth = 5)',
       title = 'Survival Rate by Age')
    
# Titanic passenger survival rate by age using box plot
ggplot(titanic, aes(x = Survived, y = Age)) + 
  theme_gray() + 
  geom_boxplot() +   
  labs(y = ' Age', 
       x = 'Survived',
       title = 'Survival Rate by Age')

# Titanic passenger survival rate by age,class and sex using density plot, delete later
ggplot(titanic, aes(x = Age, fill= Survived)) + 
  theme_gray() + 
  facet_wrap(Sex ~ Pclass) +
  geom_density(alpha = 0.5) + 
  labs(y = 'Survived',
       x = 'Age',
       title = 'Survival Rate by Age, Class and Sex')

# Titanic passenger survival rate by age,class and sex using histrogram
ggplot(titanic, aes(x = Age, fill= Survived)) + 
  theme_gray() + 
  facet_wrap(Sex ~ Pclass) +
  geom_histogram(binwidth = 5) + 
  labs(y = 'Survived',
       x = 'Age',
       title = 'Survival Rate by Age, Class and Sex')